"use client";

import React from "react";
import { useOperators } from "./hooks/useOperators";
import { OperatorHeader } from "./components/OperatorHeader";
import { OperatorForm } from "./components/OperatorForm";
import { OperatorTable } from "./components/OperatorTable";

export default function OperatorsPage() {
  const {
    operators,
    isLoading,
    form,
    isSubmitting,
    updateForm,
    handleAddOperator,
    handleDelete
  } = useOperators();

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      {/* 운영자 관리 헤더 영역 */}
      <OperatorHeader />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 새 운영자 추가 폼 영역 */}
        <div className="lg:col-span-1">
          <OperatorForm 
            form={form}
            isSubmitting={isSubmitting}
            onUpdateField={updateForm}
            onSubmit={handleAddOperator}
          />
        </div>

        {/* 운영자 목록 테이블 영역 */}
        <div className="lg:col-span-2">
          <OperatorTable 
            isLoading={isLoading}
            operators={operators}
            onDelete={handleDelete}
          />
        </div>
      </div>
    </div>
  );
}
